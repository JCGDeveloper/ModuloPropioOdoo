{
    'name': 'Módulo Personalizado Joaquin',
    'version': '1.0',
    'category': 'Custom',
    'summary': 'Módulo personalizado de Joaquin',
    'description': """
        Módulo Personalizado de Joaquin
        ================================
        
        Este es un módulo personalizado desarrollado para Odoo.
    """,
    'author': 'Joaquin',
    'website': 'https://www.example.com',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.xml',
        'views/test_model_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}

