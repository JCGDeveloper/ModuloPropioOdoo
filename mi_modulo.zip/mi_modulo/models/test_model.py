# -*- coding: utf-8 -*-

from odoo import models, fields


class XTestModel(models.Model):
    _name = 'x_test_model'
    _description = 'Modelo de Prueba'
    _order = 'name'

    name = fields.Char(string='Nombre', required=True, index=True)
    description = fields.Text(string='Descripción')
    active = fields.Boolean(string='Activo', default=True)
    date_created = fields.Datetime(string='Fecha de Creación', default=fields.Datetime.now, readonly=True)

